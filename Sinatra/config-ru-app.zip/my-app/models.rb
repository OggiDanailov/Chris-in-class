class Blog < ActiveRecord::Base
	belongs_to :user
	has_many :comments, dependent: :destroy
end

class User < ActiveRecord::Base
	has_many :blogs, dependent: :destroy
	has_many :comments

	validates :username, uniqueness: true, presence: true
	validates :password, presence: true
	# validates_presence_of :username, :password
end

class Comment < ActiveRecord::Base
	belongs_to :user
	belongs_to :blog
end
