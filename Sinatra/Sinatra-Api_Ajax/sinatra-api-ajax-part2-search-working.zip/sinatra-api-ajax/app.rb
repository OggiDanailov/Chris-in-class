get '/' do
	erb :index
end

get '/search' do
	erb :search
end

post '/signin' do
	user = User.where(username: params[:username]).first
	if user.password == params[:password]
		flash[:notice] = "Successfully Signed In"
		redirect '/search'
	else
		flash[:error] = "Wrong password. 2 tries remaining."
		redirect '/'
	end

end

post '/signup' do
	user = User.new(params[:user])
	if user.save
		flash[:notice] = "Successfully Created New User"
		redirect '/search'
	else
		flash[:error] = user.errors.full_messages
		redirect '/'
	end

end






#
