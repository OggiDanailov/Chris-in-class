var searchBtn = document.getElementById("search");
var searchTerm = document.getElementById("searchTerm");

searchBtn.addEventListener("click", searchGoogleBooks);

function searchGoogleBooks() {
	var term = searchTerm.value;

	$.ajax({
		method: "GET",
		url: "https://www.googleapis.com/books/v1/volumes",
		data: {
			q: term
		},
		dataType: 'json',
		success: function(response) {
			console.log(response);

		}
	})
}
