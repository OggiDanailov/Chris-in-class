var searchBtn = document.getElementById("search");
var searchTerm = document.getElementById("searchTerm");
var results = document.getElementsByClassName("results")[0];

searchBtn.addEventListener("click", searchGoogleBooks);

function searchGoogleBooks() {
	var term = searchTerm.value;

	$.ajax({
		method: "GET",
		url: "https://www.googleapis.com/books/v1/volumes",
		data: {
			q: term
		},
		dataType: 'json',
		success: function(response) {
			response.items.forEach(function(book) {
				var resultDiv = document.createElement("div");
				resultDiv.classList.add("result");
				resultDiv.innerHTML = book.volumeInfo.title;
				results.append(resultDiv);
				resultDiv.addEventListener("click", function() {
					addBookToDb(book);
				});
			});

		}
	})
}


function addBookToDb(book) {
	var title = book.volumeInfo.title;
	var author = book.volumeInfo.authors[0];

	$.ajax({
		method: "POST",
		url: "/books",
		data: {
			title: title,
			author: author
		}
	})

}









//
