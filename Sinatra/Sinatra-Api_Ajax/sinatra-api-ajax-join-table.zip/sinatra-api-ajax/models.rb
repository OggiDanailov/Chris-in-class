class User < ActiveRecord::Base

	has_many :books

	# validates_presence_of :password, :username
	validates :username, uniqueness: true, presence: true
	validates :password, presence: true

end

class Book < ActiveRecord::Base
	belongs_to :user
	has_many :book_tags
	has_many :tags, through: :book_tags
end

class Tag < ActiveRecord::Base
	has_many :book_tags
	has_many :books, through: :book_tags
end

class BookTag < ActiveRecord::Base
	belongs_to :book
	belongs_to :tag
end




#
