
var employees = ["Chris", "Emily", "Oggi"];

var whoWorksHere = employees.map(function(employee) {
	return employee + " works here"
})

console.log(whoWorksHere);




// response = {
// 	books: [
// 		{
// 			prop1: {},
// 			prop2: {},
// 			prop3: {},
// 			id: "eigjeogijaogjaig",
// 			volumeInfo: {
// 				title: "Dune",
// 				authors: ["Frank Herbert"],
// 				description: "A cool book"
// 				}
// 			},
// 			{
// 				prop1: {},
// 				prop2: {},
// 				prop3: {},
// 				id: "eigjeogijaogjaig",
// 				volumeInfo: {
// 					title: "Dune",
// 					authors: ["Frank Herbert"],
// 					description: "A cool book"
// 				}
// 			},
// 			{
// 				prop1: {},
// 				prop2: {},
// 				prop3: {},
// 				id: "eigjeogijaogjaig",
// 				volumeInfo: {
// 					title: "Dune",
// 					authors: ["Frank Herbert"],
// 					description: "A cool book"
// 				}
// 			},
// 			{
// 				prop1: {},
// 				prop2: {},
// 				prop3: {},
// 				id: "eigjeogijaogjaig",
// 				volumeInfo: {
// 					title: "Dune",
// 					authors: ["Frank Herbert"],
// 					description: "A cool book"
// 				}
// 			}
// 	]
// }

// books = [];
//
// response.books.forEach(function(book) {
// 	books.push(book.volumeInfo)
// })


// books = response.books.map(function(book) {
// 	return book.volumeInfo;
// });

// console.log(books);
