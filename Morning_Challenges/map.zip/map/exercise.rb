names = ["Chris", "Emily", "Oggi"]

["Chris", "Emily", "Oggi"].map { |name| "#{name} works here" }
