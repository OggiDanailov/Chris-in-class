// var btnOne = document.getElementById("buttonOne");

// btnOne.addEventListener("click", function() {
// 	alert("I'm the first button.");
// });

// btnOne.addEventListener("click", runAlert);

// function runAlert() {
// 	alert("I'm the first button from the runAlert function.")
// }


// var btns = document.getElementsByClassName("button");

// console.log(btns);

// for (let i = 0; i < btns.length; i++) {
// 	btns[i].addEventListener("click", function(){
// 		if (btns[i].innerHTML === "I was clicked!") {
// 			btns[i].innerHTML = "Button " + (i + 1) + " needs to be clicked.";
// 		} else {
// 			btns[i].innerHTML = "I was clicked!";
// 		}
// 	});
// }


// for (let i = 0; i < btns.length; i++) {
// 	btns[i].addEventListener("click", changeBtnText);
// }

var btns = document.getElementsByClassName("button");

console.log(btns);

// for (let i = 0; i < btns.length; i++) {
// 	btns[i].addEventListener("click", function() {
// 		changeBtnText(btns[i]);
// 	});
// }

// function changeBtnText(btn) {
// 	btn.innerHTML = "I was clicked";
// }

for (var i = 0; i < btns.length; i++) {
	btns[i].addEventListener("click", changeBtnText);
}

function changeBtnText(event) {
	event.target.innerHTML = "I was clicked using event.";
}




