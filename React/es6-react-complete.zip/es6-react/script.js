

// class Product {
//
// 	constructor(name, price) {
// 		this.name = name;
// 		this.price = price;
// 	}
//
// 	sayPrice() {
// 		return "This product costs " + this.price;
// 	}
//
//
// }



class Mammal {

	constructor() {
		this.warmBlood = true;
	}

}

class Monkey extends Mammal {

	constructor() {
		super();
	}

}










// function Products(name, price) {
// 	this.name = name;
// 	this.price = price;
// 	this.sayPrice = sayPrice;
//
// 	function sayPrice() {
// 		return "This product costs " + this.price;
// 	}
// }





//
