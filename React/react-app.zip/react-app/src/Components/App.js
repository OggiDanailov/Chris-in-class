import React, { Component } from 'react';
import axios from 'axios';
import logo from '../logo.svg';
import '../Stylesheets/App.css';
import YelpSearch from './YelpSearch';
import YelpResults from './YelpResults';


class App extends Component {

	constructor(props) {
		super(props);
		this.state = {
			businesses: [],
			showFavorites: false
		}

		this.searchApi = this.searchApi.bind(this);
		this.showFavorites = this.showFavorites.bind(this);

	}

	render() {

		if (this.state.showFavorites) {
			return(
				<div>
					<button onClick={this.showFavorites}>Show Search</button>
					<div>My favorites would be here!</div>
				</div>
			)
		} else {

			return(
				<div>
					<button onClick={this.showFavorites}>Show Favorites</button>
					<YelpSearch search={this.searchApi}/>
					<YelpResults results={this.state.businesses} />
				</div>
			)

		}

	}

	showFavorites() {
		this.setState({showFavorites: !this.state.showFavorites})
	}

	searchApi(searchParams) {
		axios.get("https://yelp-search.herokuapp.com/search", {
			params: searchParams
		}).then(function(response) {
			this.setState({businesses: response.data.businesses})

		}.bind(this))
	}


}

export default App;
