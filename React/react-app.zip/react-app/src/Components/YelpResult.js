import axios from 'axios';
import React, { Component } from 'react';

function YelpResult(props) {
	return(
		<div>
			<div>{props.business.name}</div>
			<div>{props.business.phone}</div>
			<img src={props.business.img} alt=""/>
			<button onClick={sendFavorite}></button>
		</div>
	)

	function sendFavorite() {
		axios.post("/favorites", {
			params: {
				business: props.business
			}
		});
	}

}

export default YelpResult;
