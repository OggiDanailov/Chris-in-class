import React, { Component } from 'react';
import YelpResult from './YelpResult';

function YelpResults(props) {

	let businesses = props.results.map(function(result, index) {
		return(
				<YelpResult key={index} business={result} />
			)
	})

	return(
			<div>{businesses}</div>
		)

}

export default YelpResults;
