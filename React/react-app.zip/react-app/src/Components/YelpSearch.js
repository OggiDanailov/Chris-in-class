import React, { Component } from 'react';

class YelpSearch extends Component {

	constructor(props) {
		super(props);
		this.state = {
			searchTerm: "",
			searchLocation: ""
		}

		this.handleSearch = this.handleSearch.bind(this);
		this.updateTerm = this.updateTerm.bind(this);
		this.updateLocation = this.updateLocation.bind(this);
	}

	render() {

		return(
			<div>
				<input type="text" onChange={this.updateTerm} value={this.state.searchTerm} placeholder="Search Term"/>
				<input type="text" onChange={this.updateLocation} value={this.state.searchLocation} placeholder="Search Location"/>
				<button onClick={this.handleSearch}>Search!</button>
			</div>
		)

	}

	handleSearch() {
		this.props.search({term: this.state.searchTerm, location: this.state.searchLocation})
	}

	updateTerm(event) {
		this.setState({searchTerm: event.target.value});
	}

	updateLocation(event) {
		this.setState({searchLocation: event.target.value});
	}

}

export default YelpSearch;
