class HelloWorld extends React.Component {

	constructor() {
		super();
	}

	render() {
		return 	<div>Hello World!</div>
	}

}


// ReactDOM.render(
// 	<HelloWorld />,
// 	document.getElementsByClassName("react")[0]
// )

class Message extends React.Component {

	constructor(props) {
		super(props);
		this.post = {
			title: props.title,
			content: props.content
		}
	}

	render() {
		return 	<div className="post">{this.post.title}: {this.post.content}</div>
	}

}

// ReactDOM.render(
// 	<Message title="This is a Title" content="whatever" />,
// 	document.getElementsByClassName("react")[0]
// )

let blogPosts = [
	{
		title: "A good day",
		content: "Got a hoagie. Found a 20."
	},
	{
		title: "Beach Trip!",
		content: "Haha so fun."
	},
	{
		title: "Job Interview",
		content: "Went okay."
	}
]




ReactDOM.render(
	<Post />,
	document.getElementsByClassName("react")[0]
)

ReactDOM.render(
	<Blog posts={blogPosts} />,
	document.getElementsByClassName("react-2")[0]
)












//
