
// class HelloWorld extends React.Component {
//
// 	constructor() {
// 		super();
// 	}
//
// 	render() {
// 		return <div>Hello World!</div>
// 	}
//
// }

function HelloWorld() {

	return <div>Hello World! Again!</div>

}
