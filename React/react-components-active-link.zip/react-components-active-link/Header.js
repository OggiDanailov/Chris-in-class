function Header() {
	return(
		<div className="header">
			<h1>Welcome to my site!</h1>
		</div>
	)
}
