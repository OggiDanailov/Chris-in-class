

class App extends React.Component {

	constructor(props) {
		super(props);
		this.state = {
			businesses: [],
			showFavorites: false
		}

		this.searchApi = this.searchApi.bind(this);
		this.showFavorites = this.showFavorites.bind(this);

	}

	render() {

		if (this.state.showFavorites) {
			return(
				<div>
					<button onClick={this.showFavorites}>Show Search</button>
					<div>My favorites would be here!</div>
				</div>
			)
		} else {

			return(
				<div>
					<button onClick={this.showFavorites}>Show Favorites</button>
					<YelpSearch search={this.searchApi}/>
					<YelpResults results={this.state.businesses} />
				</div>
			)

		}

	}

	showFavorites() {
		this.setState({showFavorites: !this.state.showFavorites})
	}

	searchApi(searchParams) {
		axios.get("https://yelp-search.herokuapp.com/search", {
			params: searchParams
		}).then(function(response) {
			this.setState({businesses: response.data.businesses})

		}.bind(this))
	}


}

class YelpSearch extends React.Component {

	constructor(props) {
		super(props);
		this.state = {
			searchTerm: "",
			searchLocation: ""
		}

		this.handleSearch = this.handleSearch.bind(this);
		this.updateTerm = this.updateTerm.bind(this);
		this.updateLocation = this.updateLocation.bind(this);
	}

	render() {

		return(
			<div>
				<input type="text" onChange={this.updateTerm} value={this.state.searchTerm} placeholder="Search Term"/>
				<input type="text" onChange={this.updateLocation} value={this.state.searchLocation} placeholder="Search Location"/>
				<button onClick={this.handleSearch}>Search!</button>
			</div>
		)

	}

	handleSearch() {
		this.props.search({term: this.state.searchTerm, location: this.state.searchLocation})
	}

	updateTerm(event) {
		this.setState({searchTerm: event.target.value});
	}

	updateLocation(event) {
		this.setState({searchLocation: event.target.value});
	}

}

function YelpResults(props) {

	let businesses = props.results.map(function(result, index) {
		return(
				<YelpResult key={index} business={result} />
			)
	})

	return(
			<div>{businesses}</div>
		)

}

function YelpResult(props) {
	return(
		<div>
			<div>{props.business.name}</div>
			<div>{props.business.phone}</div>
			<img src={props.business.img} alt=""/>
			<button onClick={sendFavorite}></button>
		</div>
	)

	function sendFavorite() {
		axios.post("/favorites", {
			params: {
				business: props.business
			}
		});
	}

}



ReactDOM.render(
	<App />,
	document.getElementById("react")
)
