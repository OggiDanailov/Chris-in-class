class SearchResults extends React.Component {

	constructor(props) {
		super(props);
		// this.results = props.results;
		this.state = {
			results: props.results
		}
	}

	render() {
		let products = this.state.results.map(function(product, index) {
			return(
				<div key={index}>
					<div>{product.name}</div>
					<div>{product.brand}</div>
				</div>
			)
		});

		return(
			<div>
				{products}
			</div>
			)
	}

	componentWillReceiveProps(newProps) {
		this.setState({results: newProps.results});
	}

}

class SearchBar extends React.Component {

	constructor(props) {
		super(props);
		this.productList = props.products;
		this.state = {
			searchTerm: "",
			filteredProducts: props.products
		}

		this.search = this.search.bind(this);

	}

	render() {
		return(
			<div>
			<input onChange={this.search} value={this.state.searchTerm} />
			<div>{this.state.searchTerm}</div>
			<SearchResults results={this.state.filteredProducts} />
			</div>
		)
	}

	search(event) {
		let searchTerm = event.target.value.toLowerCase();
		let products = this.productList;
		if (searchTerm !== "") {
			products = products.filter(function(product) {
				return product.name.toLowerCase().includes(searchTerm) || product.brand.toLowerCase().includes(searchTerm);
			})
		}

		this.setState({searchTerm: searchTerm, filteredProducts: products})
	}

}


let productList = [
	{
		name: "Desk",
		brand: "Authentic Wood Furniture",
		price: 99.99
	},
	{
		name: "Padded Chair",
		brand: "Authentic Wood Furniture",
		price: 59.99
	},
	{
		name: "Side Table",
		brand: "Modern Trendz",
		price: 149.99
	},
	{
		name: "Skrlui Beframe",
		brand: "Sensational Sweden",
		price: 599.99
	},
	{
		name: "Minimalist Entertainment Center",
		brand: "Modern Trendz",
		price: 189.99
	},
	{
		name: "Beige Couch",
		brand: "American Furniture (From America!)",
		price: 889.99
	},
	{
		name: "Reclining Futon",
		brand: "Unique Collections",
		price: 359.99
	},

]

ReactDOM.render(
	<SearchBar products={productList} />,
	document.getElementById("react")
)
