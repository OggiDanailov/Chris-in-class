function Store(name, category, inventory) {
	this.name = name;
	this.category = category;
	this.inventory = inventory

	this.openingTime = 10;
	this.closingTime = 20;
}

var coolBoutique = new Store("xyz beau", "boutique", ["smart blouse", "hip pants"]);
var waterTaffy = new Store("NJ Salt Water Taffy", "snacks", ["green SWT", "red SWT"]);
var artStore = new Store("arts n craftz", "art", ["brush", "paint", "easel"]);
var waWa = new Store("Wawa", "regional delicacies", ["hoagie", "green tea"]);

var shoppingDistrict = [coolBoutique, waterTaffy, artStore, waWa];


// Customer.prototype = new Person();
// Employee.prototype = new Person();

function Person(name, wallet, shoes) {
	this.name = name;
	this.wallet = wallet;
	this.shoes = shoes;
}

function Employee() {
	this.currentlyWorking = true;
	Person.apply(this, arguments);
}

function Customer() {
	this.currentlyShopping = true;
	this.shoppingBag = [];
	this.purchase = purchase;
	Person.apply(this, arguments);
}

function Manager() {
	this.hasAuthority = true;
	Employee.apply(this, arguments);
}

var chris = new Customer("Chris", 25, true, "hello", "this is a random", 524342);
var joe = new Customer("Joe", 25, true);
var jane = new Customer("Jane", 25, true);
var sinead = new Customer("Sinead", 25, true);

var customers = [chris, joe, jane, sinead];

function purchase(store, item) {
	// customer.wallet -= item.price;
	this.wallet -= 10;
	var itemIndex = store.inventory.indexOf(item);
	store.inventory.splice(itemIndex, 1);
	this.shoppingBag.push(item);
}

chris.purchase(artStore, "easel");

// function listCustomers(customers) {
// 	for (var i = 0; i < customers.length; i++) {
// 		console.log(customers[i].name);
// 	}
// 	console.log("There are currently " + customers.length + " customers in the shopping district.")
// }

// var mall = {
// 	stores: [],
// 	customers: [],
// 	getshopsandcustomers: getShopsAndCustomers
// }





// function getShopsAndCustomers(shops, customers) {
// 	for (var i = 0; i < shops.length; i++) {
// 		this.stores.push(shops[i]);
// 	}
// 	for (var i = 0; i < customers.length; i++) {
// 		this.customers.push(customers[i]);
// 	}
// }










