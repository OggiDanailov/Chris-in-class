var container = document.getElementsByClassName("container")[0];

var outerDiv = document.createElement("div");
var newDiv = document.createElement("div");

outerDiv.classList.add("outer")

outerDiv.append(newDiv);

newDiv.innerHTML = "Hello! I'm the other new div.";

newDiv.addEventListener("click", function() {
	alert("Created new div");
})


container.append(outerDiv);

container.append(myImg);





// Michael's question

var divArray = [];

for (var i = 1; i <= 10; i++) {
	var newDiv = document.createElement("div");
	newDiv.classList.add("div" + i);
	container.append(newDiv);
	divArray.push(newDiv);

}




// Easier way to do image src dynamically

// var myImg = document.createElement("img");

// myImg.src = "www.images.com/i.png";



// "<img src='" + img.src + "'>";







// var newDiv = "<div class='new'>I'm a new div!!!</div>";

// container.innerHTML = newDiv;

// // addedDiv = document.getElementsByClassName("new")[0];

// newDiv.addEventListener("click", function() {
// 	alert("I'm a div!");
// })