// var numOfWheels = 2;

// var bike = {

// 	wheels: numOfWheels,
// 	frame: "cruiser",
// 	brand: "cannondale",
// 	handlebars: "flat",
// 	chain: true,
// 	gears: 1,
// 	size: 56,
// 	sizeUnit: "cm"

// }

// bike.brakes = "disc";


// var wheels = 6;

// var bike = {
// 	wheels: 2
// }

// bike.brakes = "disc";
// bike.wheels = 5;
// bike.frame =  "cruiser";
// bike.handlebars =  "flat";
// bike.chain =  true;
// bike.gears =  1;
// bike.size =  56;
// bike.sizeUnit =  "cm";


// function buyBrand(brand) {
// 	wallet -= 500;
// 	bike.brand = brand;
// }

var numOfWheels = 2;

var bike = {

	wheels: numOfWheels,
	frame: "cruiser",
	brand: "cannondale",
	handlebars: "flat",
	chain: true,
	gears: 1,
	size: 56,
	sizeUnit: "cm"

}

var funGuitar = {
	strings: 6, 
	acoustic: true,
	electric: false,
	body: "traveler",
	stringType: "steel",
	changeStrings: changeMyStrings
}

var quietGuitar = {
	strings: 6, 
	acoustic: true,
	electric: false,
	body: "traveler",
	stringType: "nylon",
	changeStrings: changeMyStrings
}

// function dayPlans(bikeProp, guitarProp) {
// 	return "I'm going to ride my " + bike[bikeProp] + " carrying my " + guitar[guitarProp] + ".";
// }

// dayPlans("frame", "body");


function changeMyStrings(stringAmount) {
	if (stringAmount <= 12) {
		this.strings = stringAmount;
	}
}




