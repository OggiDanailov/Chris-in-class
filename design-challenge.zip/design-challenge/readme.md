Here is a challenge to test CSS and HTML. Use SASS, Bootstrap, and anything else you think is necessary to complete this challenge. This is meant to be done over the course of a few days or weeks.

The fonts used are Open Sans and Times and you can use whatever way you would like to load them into your project.

The images are not all exactly the same as the mock-up, but they are near enough as to be sufficient.
