$(document).ready(function(){

	var ajaxResponse;

	$(".search").on("click", function() {
		var inputValue = document.getElementsByClassName("search-term")[0].value;
		console.log(inputValue);
		runAjaxRequest(inputValue);
		console.log(ajaxResponse);
	})

	function runAjaxRequest(inputText) {
		$.ajax({
			url: "http://www.omdbapi.com/?",
			data: {
				s: inputText
			},
			dataType: "json",
			success: function(response) {
				console.log(response);
				ajaxResponse = response;
				for (var i = 0; i < response.Search.length; i++) {
					createSearchResult(response.Search[i])
				}
			}

		})

	}

	function createSearchResult(movie) {
		var searchResults = document.getElementsByClassName("search-results")[0];
		var resultDiv = "<div class='result'><img src='" + movie.Poster + "'>Title: " + movie.Title + "</div>";
		searchResults.innerHTML += resultDiv;
	}

});






// var content = $(".content")