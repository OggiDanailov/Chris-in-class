import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Link } from 'react-router-dom';
import Home from './Home';
import About from './About';
import Destinations from './Destinations';
import axios from 'axios';

class App extends Component {

  constructor() {
    super();
    this.state = {
      destinations: []
    }

    this.createDestinations = this.createDestinations.bind(this);

  }


  render() {
    return (
      <div className="App">
        <BrowserRouter>
          <div>
            <ul>
              <li><Link to="/">Home</Link></li>
              <li><Link to="/about">About</Link></li>
              <li><Link to="/destinations">Destinations</Link></li>
            </ul>
            <Route exact path="/" component={Home} />
            <Route path="/about" component={About} />
            <Route path="/destinations" component={this.createDestinations} />
          </div>
        </BrowserRouter>
      </div>
    );
  }

  createDestinations() {
      return <Destinations list={this.state.destinations} />
  }

  componentWillMount() {
    axios.get("/destinations").then(function(response) {
      this.setState({destinations: response.data});
    }.bind(this));
  }

}

export default App;
