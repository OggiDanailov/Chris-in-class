import React, { Component } from 'react';

function Destinations(props) {

	let destinations = props.list.map(function(destination) {
		return(
			<div>
				<img src={destination.img_url} height="300" width="400" alt=""/>
				<div>{destination.name}</div>
				<div>{destination.description}</div>
			</div>
		)
	});

	return <div>{destinations}</div>
}

export default Destinations;
