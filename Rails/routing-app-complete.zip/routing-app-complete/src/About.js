import React, { Component } from 'react';
import { BrowserRouter, Route, Link } from 'react-router-dom';

class About extends Component {


	render() {
		return <div>About</div>
	}

}

export default About;
